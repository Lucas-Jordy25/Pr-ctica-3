# Práctica 3: Diseño responsivo con Contraints 
<img src="practica_ui.png" width="700" height="400">
<img src="practica_ui2.png" width="700" height="400">
